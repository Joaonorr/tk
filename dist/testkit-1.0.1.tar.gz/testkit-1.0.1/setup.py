from setuptools import setup

setup(
    name = 'testkit',
    version = '1.0.1',
    author = "David Sena Oliveira",
    author_email = "sena@ufc.br",
    package = ['testkit'],
    description = "",
    long_description = "",
    url = "https://github.com/senapk/tk",
    project_urls = {
        'Código fonte': 'https://github.com/senapk/tk',
    },
    license = 'MIT'
)